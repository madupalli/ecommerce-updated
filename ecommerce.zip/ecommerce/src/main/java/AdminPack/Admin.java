package AdminPack;
import User.User;

public class Admin extends User {

	public Admin(int user_id, String name, String password) {
		super(user_id, name, password);
		// TODO Auto-generated constructor stub
	}
	 


}
